﻿//removed namespace for it to be global
public class Menu_list
{

    public string mealName { get; set; }
    public double price { get; set; }

    public int mealNo { get; set; }


}

