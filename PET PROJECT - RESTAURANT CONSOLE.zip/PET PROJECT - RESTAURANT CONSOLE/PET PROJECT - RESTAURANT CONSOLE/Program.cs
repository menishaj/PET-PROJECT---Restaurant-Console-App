﻿
using PET_PROJECT___RESTAURANT_CONSOLE.Helpsrs;
using PET_PROJECT___RESTAURANT_CONSOLE.Models;
using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text.Json;

namespace PET_PROJECT___RESTAURANT_CONSOLE
{
    class Program
    {
        static void Main(string[] args)
        {
            //instantiate object

            MenuHelper menuhelper = new MenuHelper();



            Console.WriteLine("WELCOME TO MO-RESTAURANT!");
            Console.WriteLine();
            Console.WriteLine("--------------------MENU-------------------");
            Console.WriteLine();



            string menuJsonData = File.ReadAllText("C:\\Users\\mjugoo\\source\\repos\\PET PROJECT - RESTAURANT CONSOLE\\PET PROJECT - RESTAURANT CONSOLE\\menu.json");
            //deserialize json into list
            var menuList = JsonSerializer.Deserialize<List<Menu_list>>(menuJsonData);
            //check if menu list is null 
            if (menuList != null)
            {


                foreach (var menu in menuList)
                {

                    //String interpolation - Inject object into string
                    Console.WriteLine($"{menu.mealNo}\t{menu.mealName}\t \t{menu.price}");
                    //Result: 1 Chicken Pad Thai 1 325









                }
            }
            Console.WriteLine();
            string fname;
            Console.WriteLine("Please enter your first name");
            fname = Console.ReadLine();
            string lname;
            Console.WriteLine("Please enter your last name");
            lname = Console.ReadLine();

            //Console.WriteLine("Please enter your first name");
            //Console.ReadLine();
            //Console.WriteLine("Please enter your last name");
            //Console.ReadLine();

            Console.WriteLine("Please select the meal number to order:");






            // Create a string variable and get user input from the keyboard and store it in the variable
            string meal = Console.ReadLine();
            Console.WriteLine();

            Console.WriteLine("Details:");
            List<SelectedItem> ItemList = new List<SelectedItem>();


           

            while (true)
            {
                int menuIdInt;

                if (Int32.TryParse(meal, out menuIdInt))
                {
                    menuIdInt = Int32.Parse(meal);
                }
                //switch case to display meal names
                var selectedMeal = menuList.Where(x => x.mealNo.Equals(menuIdInt)).FirstOrDefault();


                if (selectedMeal != null)
                {
                    var selectedItem = new SelectedItem();
                    selectedItem.MealName = selectedMeal.mealName;
                    selectedItem.MenuId = selectedMeal.mealNo;

                    displayMenu(selectedMeal.mealName);

                    Console.WriteLine("Please enter quantity and -1 to cancel");
                    int quantityInt = 0;
                    string quantity = Console.ReadLine();


                    //convert to int
                    if (Int32.TryParse(quantity, out quantityInt))
                    {
                        quantityInt = Int32.Parse(quantity);
                    }




                    //check if value is -1, do not add to list

                    if (quantityInt != -1)
                    {

                        selectedItem.Quantity = quantityInt;
                        ItemList.Add(selectedItem);


                    }




                    //Console.Read();
                    Console.WriteLine("Press X to exit or order another menu item");


                    ConsoleKey key;
                    key = Console.ReadKey(true).Key;


                    if (key == ConsoleKey.X)
                    {
                        Console.Clear();
                        Console.WriteLine("THANK YOU FOR YOUR VISIT!");
                        Console.WriteLine();
                        Console.Beep();
                        break;
                    }
                    else if (key == ConsoleKey.C)
                    {

                        Console.WriteLine("Please select the meal number to order:");

                        // Create a string variable and get user input from the keyboard and store it in the variable




                    }


                    meal = Console.ReadLine();




                }
                else
                {


                    Console.WriteLine("Meal not found ");

                }






                

            }


            Console.WriteLine("Here is your purchase!");
            Console.WriteLine();
            Console.WriteLine("Customer name:" + " " + string.Concat(fname, " ", lname));

            var total = 0.0;

            foreach (var userinput in ItemList)
            {
                
                var x = menuhelper.TotalPricePerMenu(menuList, userinput.MenuId, userinput.Quantity);
                total = total + x;
                Console.WriteLine(userinput.MenuId + " " + userinput.MealName + " " + userinput.Quantity + " " + x);

            }
            Console.WriteLine("Total amount to be paid:" +total);

            Console.WriteLine();
            Console.WriteLine("purchase completed!");








        }



        private static void displayMenu(string menuName)
        {
            Console.WriteLine("Your meal " + menuName);
        }


    }

}


